#include <iostream>
using namespace std;
class Stack{
private:
    int top;
    int maxSize = 10;
    int arr[10];
public:
    stack(){
    top = 0; maxSize=10;}
    void push(int v){
        if (top<maxSize)
            arr[top++]=v;

    else{
        cout<<"stack is full"<<endl;
    }
}
    void pop(){
        if (top>0)
            top--;
        else{
            cout<<"Stack is empty"<<endl;
        }
    }
    bool isFull(){
        if (top == maxSize)
            top++;
        else{
            cout<<"false"<<endl;
        }
    }
    bool isEmpty(){
        if (top == 0)
            top++;
        else{
            cout<<"False"<<endl;
        }
    }
    int getTopValue(){
        if(!isEmpty()){return arr[top-1];}
        else{
            cout<<"stack is empty"<<endl;
        }
    }
    void showValues(){
        for (int i =0; i<top; i++){
            cout<<arr[i]<<" ";
        }
    cout<<endl;
    }
};
int main()
{
   Stack s;
   s.push(12);
   s.push (13);
   s.push(15);
   s.pop();
   s.pop();
   s.pop();
s.push(10);
   s.pop();
   s.pop();
   s.pop();
   s.push(65);
   s.push(76);
   s.push(34);
   s.pop();
   cout<<s.getTopValue()<<endl;
   s.pop();
   cout<<s.getTopValue()<<endl;
   s.pop();

    return 0;
}
